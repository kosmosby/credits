ALTER TABLE [#__fields_groups] ADD [params] [text] NOT NULL DEFAULT '';
